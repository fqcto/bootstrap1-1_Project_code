<?php
session_start();
include '../../public/common/config.php';

$code=time().mt_rand();
$user_id=$_SESSION['home_userid'];
$time=time();
$touch_id=$_POST['touch_id'];

if($user_id){
	if($touch_id){
		foreach($_SESSION['shops'] as $shop){
		$sql="insert into indent(code,user_id,time,touch_id,shop_id,price,num) values('{$code}','{$user_id}','{$time}','{$touch_id}','{$shop['id']}','{$shop['price']}','{$shop['num']}')";
		mysql_query($sql);

		//减库存
		$st=$shop['stock']-$shop['num'];
		$sqlStock="update shop set stock='{$st}' where id={$shop['id']}";
		mysql_query($sqlStock);
}

//清空购物车
$_SESSION['shops']=array();

echo "<script>alert('您的订单号为:{$code}')</script>";
echo "<script>location='../person/orderlist.php'</script>";

}else{
	echo "<script>alert('请您购物前添加联系方式，好给亲发货!')</script>";
	echo "<script>location='../cart/index.php'</script>";
}
	
}



?>