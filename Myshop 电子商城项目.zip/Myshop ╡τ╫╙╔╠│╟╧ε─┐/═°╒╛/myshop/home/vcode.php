<?php 
include '../public/common/function.php';

vcode();

?>