<?php 

echo '<script>location="admin/index.php"</script>';

?>