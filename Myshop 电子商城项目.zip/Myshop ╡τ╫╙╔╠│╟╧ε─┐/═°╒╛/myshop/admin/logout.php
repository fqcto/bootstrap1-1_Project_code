<?php


session_start();

$_SESSION['admin_username']=array();
$_SESSION['admin_userid']=array();

// session_destroy();

// setcookie('PHPSESSID','',time()-3600,'/');

echo "<script>location='login.php'</script>";

?>