<?php
include 'lock.php';
?>
<!doctype html>
<html>
<head>
	<meta charset="UTF-8">
	<title>right</title>
	<style>
		*{
			font-family: 微软雅黑;
		}	
		body{
			padding: 15px;
		}
	</style>
</head>
<body>
	<h1>welcome to myshop 商场!</h1>
	<img src="public/img/welcome.jpg" width="100%">
	<p>作者:小方</p>
</body>
</html>