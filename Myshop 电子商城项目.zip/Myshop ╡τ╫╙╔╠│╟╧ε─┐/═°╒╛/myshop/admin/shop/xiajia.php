<?php 
include '../lock.php';
include '../../public/common/config.php';

$sql="select shop.*,brand.name bname,class.name cname from shop,brand,class where brand.class_id=class.id and shop.brand_id=brand.id and shop.shelf=0";
$rst=mysql_query($sql);
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>index</title>
	<link rel="stylesheet" href="../public/css/index.css">
</head>
<body>
	<div class="main">
		<table>
			<tr>
				<th>编号</th>
				<th>名称</th>
				<th>图片</th>
				<th>价格</th>
				<th>库存</th>
				<th>货架</th>
				<th>品牌</th>
				<th>分类</th>
				<th>修改</th>
				<th>删除</th>
			</tr>	
			<?php 
				while($row=mysql_fetch_assoc($rst)){
					echo "<tr>";
					echo "<td>{$row['id']}</td>";
					echo "<td>{$row['name']}</td>";
					echo "<td><img src='../../public/uploads/{$row['img']}' width='50px'></td>";
					echo "<td>{$row['price']}</td>";
					echo "<td>{$row['stock']}</td>";
					if($row['shelf']){
						echo "<td>上架</td>";
					}else{
						echo "<td>下架</td>";
					}
					echo "<td>{$row['bname']}</td>";
					echo "<td>{$row['cname']}</td>";
					echo "<td><a href='edit.php?id={$row['id']}'>修改</a></td>";
					echo "<td><a href='delete.php?id={$row['id']}&img={$row['img']}'>删除</a></td>";
					echo "</tr>";
				}
			?>
		</table>
	</div>
	
</body>
</html>