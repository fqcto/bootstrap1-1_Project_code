<?php
include 'lock.php';
?>
<!doctype html>
<html>
<head>
	<meta charset="UTF-8">
	<title>top</title>
	<style>
	*{
		font-family: 微软雅黑;
	}
	body{
		background: #272822;
		color: #fff;
	}
	</style>
</head>
<body>
<h1>欢迎登陆小方myshop 后台!</h1>
</body>
</html>