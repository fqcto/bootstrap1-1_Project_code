<?php
include '../lock.php';
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>index</title>
	<link rel="stylesheet" href="../public/css/index.css">
</head>
<body>
	<div class="main">
		<form action="insert.php" method="post">
			<p>分类名称:</p>
			<p><input type="text" name="name"></p>

			<p id="btn"><input type="submit" value="添加"></p>
		</form>
	</div>
</body>
</html>

